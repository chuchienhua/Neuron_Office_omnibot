var searchData=
[
  ['bytesize_5ft',['bytesize_t',['../namespaceserial.html#a00b3281fa11cea770c0b0c8a106080f8',1,'serial']]]
];
