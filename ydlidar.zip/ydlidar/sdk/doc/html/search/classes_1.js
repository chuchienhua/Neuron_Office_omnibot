var searchData=
[
  ['device_5fhealth',['device_health',['../structdevice__health.html',1,'']]],
  ['device_5finfo',['device_info',['../structdevice__info.html',1,'']]]
];
