var searchData=
[
  ['description',['description',['../structserial_1_1_port_info.html#a2ba37dd33d47b554aef5c15c1fe8b872',1,'serial::PortInfo']]],
  ['device_5fid',['device_id',['../structserial_1_1_port_info.html#af6a8211d14bccb07b538ac584d195466',1,'serial::PortInfo']]],
  ['distance_5fq2',['distance_q2',['../structnode__info.html#a82eaf27a6196e803d3618c83b052f78c',1,'node_info']]]
];
